//(c) A+ Computer Science
//www.apluscompsci.com
//Name -

import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;

class SpeedUpBall extends Ball
{

   //instance variables

   public SpeedUpBall()
   {


   }

   public SpeedUpBall(int x, int y)
   {


   }


   public SpeedUpBall(int x, int y, int xSpd, int ySpd)
   {


   }

   public SpeedUpBall(int x, int y, int wid, int ht, int xSpd, int ySpd)
   {


   }


   public SpeedUpBall(int x, int y, int wid, int ht, Color col, int xSpd, int ySpd)
   {




   }

   public void setXSpeed( int xSpd )
   {




   }

   public void setYSpeed( int ySpd )
   {




   }
}

